var filterRunnerServiceMock = {
    filters:{},
    activeFilters: [],
    allData: [],
    filteredData: [],
    clearFilters: function() {},
    setFilters: function(filterName) {},
    filter: function() {}
};