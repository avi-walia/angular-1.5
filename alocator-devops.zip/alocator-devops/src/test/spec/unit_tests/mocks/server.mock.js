var serverMockConstructor = function() {
    return {

    };
}