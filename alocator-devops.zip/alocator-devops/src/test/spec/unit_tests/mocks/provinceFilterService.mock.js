var provinceFilterServiceMock = {
    defaultValue: 'Province',
    globalLanguage: 'Bilingual',
    label: 'province',
    value: 'Province',
    options: [
        'Province',
        'AB',
        'BC',
        'MB',
        'NB',
        'NL',
        'NS',
        'NT',
        'NU',
        'ON',
        'PE',
        'QC',
        'SK',
        'YT'
    ],
    filterFunc: function(advisor) {}
}